﻿namespace Clinic_System
{
    partial class FrmPatientAppointments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAppointmentHeader = new System.Windows.Forms.Label();
            this.btnNewAppointment = new System.Windows.Forms.Button();
            this.dgvAppointments = new System.Windows.Forms.DataGridView();
            this.numberOfAppointments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Reason = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmEdit = new Krypton.Toolkit.KryptonDataGridViewButtonColumn();
            this.ClmDelete = new Krypton.Toolkit.KryptonDataGridViewButtonColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.lblAppointmentCountP = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAppointments)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAppointmentHeader
            // 
            this.lblAppointmentHeader.AutoSize = true;
            this.lblAppointmentHeader.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAppointmentHeader.Location = new System.Drawing.Point(281, 18);
            this.lblAppointmentHeader.Name = "lblAppointmentHeader";
            this.lblAppointmentHeader.Size = new System.Drawing.Size(186, 25);
            this.lblAppointmentHeader.TabIndex = 0;
            this.lblAppointmentHeader.Text = "Your Appointments";
            this.lblAppointmentHeader.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnNewAppointment
            // 
            this.btnNewAppointment.Location = new System.Drawing.Point(74, 75);
            this.btnNewAppointment.Name = "btnNewAppointment";
            this.btnNewAppointment.Size = new System.Drawing.Size(66, 36);
            this.btnNewAppointment.TabIndex = 2;
            this.btnNewAppointment.Text = "New";
            this.btnNewAppointment.UseVisualStyleBackColor = true;
            this.btnNewAppointment.Click += new System.EventHandler(this.btnNewAppointment_Click);
            // 
            // dgvAppointments
            // 
            this.dgvAppointments.AllowUserToAddRows = false;
            this.dgvAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAppointments.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numberOfAppointments,
            this.ID,
            this.Date,
            this.Reason,
            this.ClmEdit,
            this.ClmDelete});
            this.dgvAppointments.Location = new System.Drawing.Point(74, 117);
            this.dgvAppointments.Name = "dgvAppointments";
            this.dgvAppointments.RowTemplate.Height = 25;
            this.dgvAppointments.Size = new System.Drawing.Size(646, 306);
            this.dgvAppointments.TabIndex = 3;
            this.dgvAppointments.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // numberOfAppointments
            // 
            this.numberOfAppointments.HeaderText = "#";
            this.numberOfAppointments.Name = "numberOfAppointments";
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            // 
            // Reason
            // 
            this.Reason.HeaderText = "Reason";
            this.Reason.Name = "Reason";
            // 
            // ClmEdit
            // 
            this.ClmEdit.ButtonStyle = Krypton.Toolkit.ButtonStyle.LowProfile;
            this.ClmEdit.HeaderText = "";
            this.ClmEdit.Name = "ClmEdit";
            // 
            // ClmDelete
            // 
            this.ClmDelete.HeaderText = "";
            this.ClmDelete.Name = "ClmDelete";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(587, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "Appointent Count:";
            // 
            // lblAppointmentCountP
            // 
            this.lblAppointmentCountP.AutoSize = true;
            this.lblAppointmentCountP.Location = new System.Drawing.Point(699, 86);
            this.lblAppointmentCountP.Name = "lblAppointmentCountP";
            this.lblAppointmentCountP.Size = new System.Drawing.Size(13, 15);
            this.lblAppointmentCountP.TabIndex = 4;
            this.lblAppointmentCountP.Text = "0";
            // 
            // FrmPatientAppointments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblAppointmentCountP);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvAppointments);
            this.Controls.Add(this.btnNewAppointment);
            this.Controls.Add(this.lblAppointmentHeader);
            this.Name = "FrmPatientAppointments";
            this.Text = "Patient Appointments";
            this.Load += new System.EventHandler(this.FrmPatientAppointments_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAppointments)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblAppointmentHeader;
        private DataGridView dgvAppointments;
        private Button btnNewAppointment;
        private DataGridViewTextBoxColumn numberOfAppointments;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn Date;
        private DataGridViewTextBoxColumn Reason;
        private Krypton.Toolkit.KryptonDataGridViewButtonColumn ClmEdit;
        private Krypton.Toolkit.KryptonDataGridViewButtonColumn ClmDelete;
        private Label label1;
        private Label lblAppointmentCountP;
    }
}