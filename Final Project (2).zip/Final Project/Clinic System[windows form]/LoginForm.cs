﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic_System
{
    public partial class FrmLogin : Form
    {
        Double count = 0;
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnBackFromLogin_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            FrmClinicManagement frmSplashScreen = new FrmClinicManagement();
            frmSplashScreen.Show();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                try {
                    Connection connection = new Connection();
                    connection.Open();
                    string query = "select User_ID,Username,Upassword,User_Role_ID from user_login_tbl WHERE username ='" + txtUsername.Text + "' AND Upassword ='" + txtPassword.Text + "'";
                    DataTable userDataTable = new DataTable();
                    MySqlDataReader row;
                    row = connection.ExecuteReader(query);
             
                    if (row.HasRows)
                    {
                        // Fetch userID
                        userDataTable.Load(row);
                        DataRow userRow = userDataTable.Rows[0];


                        // Check patient loggin
                        if(Convert.ToInt32(userRow["User_Role_ID"]) == 1) {
                            ShowUsername.patientID = Convert.ToInt32(userRow["User_ID"]);
                            //DataRow userRowUsername = userDataTable.Rows[1];
                            ShowUsername.displayName = userRow["Username"].ToString();

                            // Use the userID to capture the patient details
                            // Assign those capture details and save them to the class properties

                            // TODO: check in here to see user role
                            //ShowUsername.displayName = txtUsername.Text;
                            MessageBox.Show(txtUsername.Text, "Login Success!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Visible = false;
                            FrmPatientDashboard patient_dashboard = new FrmPatientDashboard();
                            patient_dashboard.Show();
                            connection.Close();
                        }else if (Convert.ToInt32(userRow["User_Role_ID"]) == 2) {
                            ShowDoctor.DoctorUserID = Convert.ToInt32(userRow["User_ID"]);
                            FrmDoctorDashboard frmDoctor = new FrmDoctorDashboard();
                            MessageBox.Show(txtUsername.Text, "Login Success!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Visible = false;
                            frmDoctor.Show();
                            connection.Close();
                        }
    

                        // Check doctor loggin

                        /*if (row["userRoleID"].ToString() == "1"){
                            MessageBox.Show(txtUsername.Text, "Login Success!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Visible = false;
                            FrmPatientDashboard patient_dashboard = new FrmPatientDashboard();
                            patient_dashboard.Show();
                        }
                        else if(row["User_Role_ID"].ToString() == "2")
                        {
                            MessageBox.Show(txtUsername.Text, "Login Success!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Visible = false;
                            FrmDoctorDashboard doctor_dashboard = new FrmDoctorDashboard();
                            doctor_dashboard.Show();
                        }*/

                    }
                    else
                    {
                        count = count + 1;
                        double maxcount = 3;
                        double remain;
                        remain = maxcount - count;
                        MessageBox.Show("Wrong user name or password" + "\t" + remain + "" + "tries left");
                        txtUsername.Clear();
                        txtPassword.Clear();
                        txtUsername.Focus();

                        if (count == maxcount)
                        {
                            MessageBox.Show("Max tries exceeded.");
                            Application.Exit();
                        }
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Connection Error", "Information");
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void txtUsername_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtUsername.Text))
            {
                e.Cancel = true;
                txtUsername.Focus();
                loginFormErrorProvider.SetError(txtUsername, "Username cannot be empty");
            }
            else
            {
                e.Cancel = false;
                loginFormErrorProvider.SetError(txtUsername, null);
            }
        }

        private void txtPassword_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtPassword.Text))
            {
                e.Cancel = true;
                txtPassword.Focus();
                loginFormErrorProvider.SetError(txtPassword, "Password cannot be empty");
            }
            else
            {
                e.Cancel = false;
                loginFormErrorProvider.SetError(txtPassword, null);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void kryptonButton2_Click(object sender, EventArgs e)
        {

        }

        private void kryptonButton1_Click(object sender, EventArgs e)
        {
                    }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblPassword_Click(object sender, EventArgs e)
        {

        }

        private void lblUsername_Click(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
