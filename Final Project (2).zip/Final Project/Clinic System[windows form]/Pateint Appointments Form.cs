﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic_System
{
    public partial class Pateint_Appointments_Form : Form
    {
        public Pateint_Appointments_Form()
        {
            InitializeComponent();
        }

        private void dgvAllPatientAppointments_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pnlAppointmentOverview_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblTotalAppoinments_Click(object sender, EventArgs e)
        {

        }

        private void lblTotalPatients_Click(object sender, EventArgs e)
        {

        }

        private void getData()
        {
            string query = "SELECT `patients_tbl`.`Patient_TRN_Number`, `patients_tbl`.`First_Name`, `patients_tbl`.`Last_Name`, `patients_tbl`.`Age`, `patients_tbl`.`Gender`, `appointments_tbl`.`Appointment_Reason`, `appointments_status_tbl`.`Status_ID`, `appointments_tbl`.`Appointed_Date` FROM `patients_tbl` LEFT JOIN `appointments_tbl` ON `appointments_tbl`.`PatientId` = `patients_tbl`.`Patient_TRN_Number` LEFT JOIN `appointments_status_tbl` ON `appointments_tbl`.`Appointment_Status_ID` = `appointments_status_tbl`.`Status_ID` WHERE `appointments_status_tbl`.`Status_ID` = '1'; ";
            Connection connection = new Connection();
            try
            {
                connection.Open();
                MySqlDataReader row;
                row = connection.ExecuteReader(query);
                if (row.HasRows)
                {
                    while (row.Read())
                    {
                        ShowAppointments.patientID.Add(row["Patient_TRN_Number"]).ToString();
                        ShowAppointments.patientFirstName.Add(row["First_Name"]).ToString();
                        ShowAppointments.patientlasttName.Add(row["Last_Name"]).ToString();
                        ShowAppointments.patientAge.Add(row["Age"]).ToString();
                        ShowAppointments.patientGender.Add(row["Gender"]).ToString();
                        ShowAppointments.appointmentReason.Add(row["Appointment_Reason"]).ToString();

                    }
                }
                else
                {
                    MessageBox.Show("Nothing could be retreived");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void updateFridTable()
        {
            dgvAllPatientAppointments.Rows.Clear();
            int count = 0;
            for (int i = 0; i < ShowAppointments.patientID.Count; i++)
            {
                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(dgvAllPatientAppointments);
                count += 1;
                newRow.Cells[0].Value = count;
                newRow.Cells[1].Value = ShowAppointments.patientID[i];
                newRow.Cells[2].Value = ShowAppointments.patientFirstName[i];
                newRow.Cells[3].Value = ShowAppointments.patientlasttName[i];
                newRow.Cells[4].Value = ShowAppointments.patientAge[i];
                newRow.Cells[5].Value = ShowAppointments.patientGender[i];
                newRow.Cells[6].Value = ShowAppointments.appointmentReason[i];
                dgvAllPatientAppointments.Rows.Add(newRow);
            }
        }

        private void Pateint_Appointments_Form_Load(object sender, EventArgs e)
        {
            Connection connection = new Connection();

            // Get Tptal Registered Patients
            connection.Open();
            string totalPatientsquery = "SELECT COUNT(*) FROM patients_tbl; ";
            DataTable totalpatientTable = new DataTable();
            MySqlDataReader row;
            row = connection.ExecuteReader(totalPatientsquery);

            totalpatientTable.Load(row);
            DataRow totalPatientRow = totalpatientTable.Rows[0];

            ShowAppointments.totalPatients = Convert.ToInt32(totalPatientRow["COUNT(*)"]);
            connection.Close();
            lblTotalPatients.Text = ShowAppointments.totalPatients.ToString();

            // Get Total Booked Appointments
            connection.Open();
            string totalBookedAppointmentsquery = "SELECT COUNT(*) FROM patients_tbl; ";
            DataTable totalBookedAppointmentTable = new DataTable();
            MySqlDataReader row1;
            row1 = connection.ExecuteReader(totalBookedAppointmentsquery);

            totalBookedAppointmentTable.Load(row);
            DataRow totalBookedAppointmentRow = totalpatientTable.Rows[0];

            ShowAppointments.totalAppointments = Convert.ToInt32(totalBookedAppointmentRow["COUNT(*)"]);
            connection.Close();
            lblTotalAppoinments.Text = ShowAppointments.totalAppointments.ToString();

            //Get Total Completed Appointments

            //populate data grid table
            getData();
            if (ShowAppointments.patientID.Count > 0)
            {
                updateFridTable();
            }
            else
            {
                MessageBox.Show("No data found");
            }

        }

    }
}