﻿namespace Clinic_System
{
    partial class FrmPatientDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPatientDashboard));
            this.pnlLeft = new System.Windows.Forms.Panel();
            this.btnViewAppointments = new System.Windows.Forms.Button();
            this.pnlUserSection = new System.Windows.Forms.Panel();
            this.kryptonPanel1 = new Krypton.Toolkit.KryptonPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblPatientUsername = new System.Windows.Forms.Label();
            this.lblPatientGreeting = new System.Windows.Forms.Label();
            this.btnAddAppointment = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblGreetings = new System.Windows.Forms.Label();
            this.lblMyInformation = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblStreetheader = new System.Windows.Forms.Label();
            this.pnlMiddle = new System.Windows.Forms.Panel();
            this.lblPatientLastName = new System.Windows.Forms.Label();
            this.lblPatientFirstName = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblPatAge = new System.Windows.Forms.Label();
            this.lblTRN = new System.Windows.Forms.Label();
            this.lblParish = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblStreet = new System.Windows.Forms.Label();
            this.lblPatientAge = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlLeft.SuspendLayout();
            this.pnlUserSection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlMiddle.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlLeft
            // 
            this.pnlLeft.Controls.Add(this.btnViewAppointments);
            this.pnlLeft.Controls.Add(this.pnlUserSection);
            this.pnlLeft.Controls.Add(this.btnAddAppointment);
            this.pnlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLeft.Location = new System.Drawing.Point(0, 0);
            this.pnlLeft.Name = "pnlLeft";
            this.pnlLeft.Size = new System.Drawing.Size(181, 336);
            this.pnlLeft.TabIndex = 1;
            this.pnlLeft.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlLeft_Paint);
            // 
            // btnViewAppointments
            // 
            this.btnViewAppointments.BackColor = System.Drawing.Color.BurlyWood;
            this.btnViewAppointments.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnViewAppointments.Location = new System.Drawing.Point(3, 258);
            this.btnViewAppointments.Name = "btnViewAppointments";
            this.btnViewAppointments.Size = new System.Drawing.Size(172, 66);
            this.btnViewAppointments.TabIndex = 3;
            this.btnViewAppointments.Text = "View Appointment";
            this.btnViewAppointments.UseVisualStyleBackColor = false;
            this.btnViewAppointments.Click += new System.EventHandler(this.button1_Click);
            // 
            // pnlUserSection
            // 
            this.pnlUserSection.Controls.Add(this.kryptonPanel1);
            this.pnlUserSection.Controls.Add(this.pictureBox1);
            this.pnlUserSection.Controls.Add(this.lblPatientUsername);
            this.pnlUserSection.Controls.Add(this.lblPatientGreeting);
            this.pnlUserSection.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlUserSection.Location = new System.Drawing.Point(0, 0);
            this.pnlUserSection.Name = "pnlUserSection";
            this.pnlUserSection.Size = new System.Drawing.Size(181, 165);
            this.pnlUserSection.TabIndex = 1;
            this.pnlUserSection.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlUserSection_Paint);
            // 
            // kryptonPanel1
            // 
            this.kryptonPanel1.Location = new System.Drawing.Point(181, 0);
            this.kryptonPanel1.Name = "kryptonPanel1";
            this.kryptonPanel1.Size = new System.Drawing.Size(637, 100);
            this.kryptonPanel1.TabIndex = 5;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(25, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(114, 94);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lblPatientUsername
            // 
            this.lblPatientUsername.AutoSize = true;
            this.lblPatientUsername.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPatientUsername.Location = new System.Drawing.Point(67, 111);
            this.lblPatientUsername.Name = "lblPatientUsername";
            this.lblPatientUsername.Size = new System.Drawing.Size(98, 25);
            this.lblPatientUsername.TabIndex = 1;
            this.lblPatientUsername.Text = "Username";
            this.lblPatientUsername.TextChanged += new System.EventHandler(this.lblPatientUsername_TextChanged);
            this.lblPatientUsername.Click += new System.EventHandler(this.lblPatientUsername_Click);
            // 
            // lblPatientGreeting
            // 
            this.lblPatientGreeting.AutoSize = true;
            this.lblPatientGreeting.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPatientGreeting.Location = new System.Drawing.Point(12, 111);
            this.lblPatientGreeting.Name = "lblPatientGreeting";
            this.lblPatientGreeting.Size = new System.Drawing.Size(62, 25);
            this.lblPatientGreeting.TabIndex = 0;
            this.lblPatientGreeting.Text = "Hello,";
            // 
            // btnAddAppointment
            // 
            this.btnAddAppointment.BackColor = System.Drawing.Color.BurlyWood;
            this.btnAddAppointment.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAddAppointment.Location = new System.Drawing.Point(3, 186);
            this.btnAddAppointment.Name = "btnAddAppointment";
            this.btnAddAppointment.Size = new System.Drawing.Size(172, 66);
            this.btnAddAppointment.TabIndex = 2;
            this.btnAddAppointment.Text = "Add Appointment";
            this.btnAddAppointment.UseVisualStyleBackColor = false;
            this.btnAddAppointment.Click += new System.EventHandler(this.btnOpenAddAppointment_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.IndianRed;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnLogout.Location = new System.Drawing.Point(521, 12);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(85, 34);
            this.btnLogout.TabIndex = 0;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click_1);
            // 
            // lblGreetings
            // 
            this.lblGreetings.AutoSize = true;
            this.lblGreetings.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point);
            this.lblGreetings.Location = new System.Drawing.Point(6, 12);
            this.lblGreetings.Name = "lblGreetings";
            this.lblGreetings.Size = new System.Drawing.Size(492, 37);
            this.lblGreetings.TabIndex = 1;
            this.lblGreetings.Text = "Welcome, Book your Appoinment Today";
            // 
            // lblMyInformation
            // 
            this.lblMyInformation.AutoSize = true;
            this.lblMyInformation.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblMyInformation.Location = new System.Drawing.Point(6, 71);
            this.lblMyInformation.Name = "lblMyInformation";
            this.lblMyInformation.Size = new System.Drawing.Size(142, 25);
            this.lblMyInformation.TabIndex = 2;
            this.lblMyInformation.Text = "My Information";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Gender";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(430, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "TRN";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(219, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Email";
            // 
            // lblStreetheader
            // 
            this.lblStreetheader.AutoSize = true;
            this.lblStreetheader.Location = new System.Drawing.Point(219, 237);
            this.lblStreetheader.Name = "lblStreetheader";
            this.lblStreetheader.Size = new System.Drawing.Size(37, 15);
            this.lblStreetheader.TabIndex = 3;
            this.lblStreetheader.Text = "Street";
            this.lblStreetheader.Click += new System.EventHandler(this.lblStreetheader_Click);
            // 
            // pnlMiddle
            // 
            this.pnlMiddle.BackColor = System.Drawing.Color.DarkGray;
            this.pnlMiddle.Controls.Add(this.lblPatientLastName);
            this.pnlMiddle.Controls.Add(this.lblPatientFirstName);
            this.pnlMiddle.Controls.Add(this.lblEmail);
            this.pnlMiddle.Controls.Add(this.lblPatAge);
            this.pnlMiddle.Controls.Add(this.lblTRN);
            this.pnlMiddle.Controls.Add(this.lblParish);
            this.pnlMiddle.Controls.Add(this.lblGender);
            this.pnlMiddle.Controls.Add(this.lblStreet);
            this.pnlMiddle.Controls.Add(this.lblStreetheader);
            this.pnlMiddle.Controls.Add(this.label2);
            this.pnlMiddle.Controls.Add(this.lblPatientAge);
            this.pnlMiddle.Controls.Add(this.label5);
            this.pnlMiddle.Controls.Add(this.label3);
            this.pnlMiddle.Controls.Add(this.label4);
            this.pnlMiddle.Controls.Add(this.label1);
            this.pnlMiddle.Controls.Add(this.lblMyInformation);
            this.pnlMiddle.Controls.Add(this.lblGreetings);
            this.pnlMiddle.Controls.Add(this.btnLogout);
            this.pnlMiddle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMiddle.Location = new System.Drawing.Point(181, 0);
            this.pnlMiddle.Name = "pnlMiddle";
            this.pnlMiddle.Size = new System.Drawing.Size(637, 336);
            this.pnlMiddle.TabIndex = 2;
            this.pnlMiddle.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlMiddle_Paint);
            // 
            // lblPatientLastName
            // 
            this.lblPatientLastName.AutoSize = true;
            this.lblPatientLastName.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPatientLastName.Location = new System.Drawing.Point(63, 156);
            this.lblPatientLastName.Name = "lblPatientLastName";
            this.lblPatientLastName.Size = new System.Drawing.Size(103, 25);
            this.lblPatientLastName.TabIndex = 4;
            this.lblPatientLastName.Text = "Last Name";
            this.lblPatientLastName.Click += new System.EventHandler(this.label7_Click);
            // 
            // lblPatientFirstName
            // 
            this.lblPatientFirstName.AutoSize = true;
            this.lblPatientFirstName.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPatientFirstName.Location = new System.Drawing.Point(11, 156);
            this.lblPatientFirstName.Name = "lblPatientFirstName";
            this.lblPatientFirstName.Size = new System.Drawing.Size(106, 25);
            this.lblPatientFirstName.TabIndex = 4;
            this.lblPatientFirstName.Text = "First Name";
            this.lblPatientFirstName.Click += new System.EventHandler(this.label7_Click);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblEmail.Location = new System.Drawing.Point(219, 156);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(59, 25);
            this.lblEmail.TabIndex = 4;
            this.lblEmail.Text = "Eamil";
            // 
            // lblPatAge
            // 
            this.lblPatAge.AutoSize = true;
            this.lblPatAge.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPatAge.Location = new System.Drawing.Point(577, 156);
            this.lblPatAge.Name = "lblPatAge";
            this.lblPatAge.Size = new System.Drawing.Size(46, 25);
            this.lblPatAge.TabIndex = 4;
            this.lblPatAge.Text = "Age";
            this.lblPatAge.Click += new System.EventHandler(this.lblPatAge_Click);
            // 
            // lblTRN
            // 
            this.lblTRN.AutoSize = true;
            this.lblTRN.BackColor = System.Drawing.Color.Transparent;
            this.lblTRN.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTRN.Location = new System.Drawing.Point(430, 159);
            this.lblTRN.Name = "lblTRN";
            this.lblTRN.Size = new System.Drawing.Size(49, 25);
            this.lblTRN.TabIndex = 4;
            this.lblTRN.Text = "TRN";
            this.lblTRN.Click += new System.EventHandler(this.lblTRN_Click);
            // 
            // lblParish
            // 
            this.lblParish.AutoSize = true;
            this.lblParish.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblParish.Location = new System.Drawing.Point(430, 266);
            this.lblParish.Name = "lblParish";
            this.lblParish.Size = new System.Drawing.Size(63, 25);
            this.lblParish.TabIndex = 4;
            this.lblParish.Text = "Parish";
            this.lblParish.Click += new System.EventHandler(this.lblParish_Click);
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblGender.Location = new System.Drawing.Point(11, 266);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(74, 25);
            this.lblGender.TabIndex = 4;
            this.lblGender.Text = "Gender";
            this.lblGender.Click += new System.EventHandler(this.lblGender_Click);
            // 
            // lblStreet
            // 
            this.lblStreet.AutoSize = true;
            this.lblStreet.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblStreet.Location = new System.Drawing.Point(219, 263);
            this.lblStreet.Name = "lblStreet";
            this.lblStreet.Size = new System.Drawing.Size(62, 25);
            this.lblStreet.TabIndex = 4;
            this.lblStreet.Text = "Street";
            this.lblStreet.Click += new System.EventHandler(this.lblStreet_Click);
            // 
            // lblPatientAge
            // 
            this.lblPatientAge.AutoSize = true;
            this.lblPatientAge.Location = new System.Drawing.Point(577, 130);
            this.lblPatientAge.Name = "lblPatientAge";
            this.lblPatientAge.Size = new System.Drawing.Size(28, 15);
            this.lblPatientAge.TabIndex = 3;
            this.lblPatientAge.Text = "Age";
            this.lblPatientAge.Click += new System.EventHandler(this.label5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(430, 237);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Parish";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // FrmPatientDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 336);
            this.Controls.Add(this.pnlMiddle);
            this.Controls.Add(this.pnlLeft);
            this.Name = "FrmPatientDashboard";
            this.Text = "PatientDashboardForm";
            this.Load += new System.EventHandler(this.FrmPatientDashboard_Load);
            this.pnlLeft.ResumeLayout(false);
            this.pnlUserSection.ResumeLayout(false);
            this.pnlUserSection.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlMiddle.ResumeLayout(false);
            this.pnlMiddle.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel pnlLeft;
        private Panel pnlUserSection;
        private Label lblPatientGreeting;
        private Label lblPatientUsername;
        private PictureBox pictureBox1;
        private Button btnAddAppointment;
        private Button btnViewAppointments;
        private Button btnLogout;
        private Label lblGreetings;
        private Label lblMyInformation;
        private Label label1;
        private Label label4;
        private Label label5;
        private Label label2;
        private Label lblStreetheader;
        private Panel pnlMiddle;
        private Label lblPatientFirstName;
        private Label lblEmail;
        private Label lblTRN;
        private Label lblGender;
        private Label lblStreet;
        private Label lblParish;
        private Label label3;
        private Label lblPatientLastName;
        private Label lblPatAge;
        private Label lblPatientAge;
        private Krypton.Toolkit.KryptonPanel kryptonPanel1;
    }
}