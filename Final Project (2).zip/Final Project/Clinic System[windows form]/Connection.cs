﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clinic_System
{
    internal class Connection
    {
        MySql.Data.MySqlClient.MySqlConnection connection;
        string connectionString;
        static string host = "127.0.0.1";
        static string database = "clinicDB";
        static string userDB = "root_admin";
        static string password = "Test@000";
        public static string strProvider = "server=" + host + ";Database=" + database + ";User ID=" + userDB + ";Password=" + password;

        public bool Open()
        {
            try
            {
                strProvider = "server=" + host + ";Database=" + database + ";User ID=" + userDB + ";Password=" + password;
                connection = new MySqlConnection(strProvider);
                connection.Open();
                return true;
            }catch(Exception ex)
            {
                MessageBox.Show("Connection Error ! " + ex.Message, "Information");
            }
            return false;
        }

        public void Close()
        {
            connection.Close();
            connection.Dispose();
        }

        public DataSet ExecutionDataSet(string sql)
        {
            try
            {
                DataSet dataset = new DataSet();
                return dataset;
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public MySqlDataReader ExecuteReader(string sql)
        {
            try
            {
                MySqlDataReader reader;
                MySqlCommand cmd = new MySqlCommand(sql, connection);
                reader = cmd.ExecuteReader();
                return reader;
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return null;

        }

        public int ExecuteNonQuery(string sql)
        {
            try
            {
                int affected;
                MySqlTransaction mytranaction = connection.BeginTransaction();
                MySqlCommand cmd = connection.CreateCommand();
                cmd.CommandText = sql;
                affected = cmd.ExecuteNonQuery();
                mytranaction.Commit();
                return affected;
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return -1;
        }
    }
}
