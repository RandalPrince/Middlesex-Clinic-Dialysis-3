namespace Clinic_System
{
    public partial class FrmClinicManagement : Form
    {
        public FrmClinicManagement()
        {
            InitializeComponent();
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            FrmLogin login_form = new FrmLogin();
            login_form.Show();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            FrmRegistration register = new FrmRegistration();
            register.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}