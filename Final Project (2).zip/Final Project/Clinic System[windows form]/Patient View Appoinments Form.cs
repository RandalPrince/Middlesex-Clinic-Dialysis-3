﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic_System
{
    public partial class FrmPatientAppointments : Form
    {
        public FrmPatientAppointments()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void getAppointments()
        {
            string query = "SELECT `patients_tbl`.`Patient_TRN_Number`, `appointments_tbl`.`AppointmentID`, `appointments_tbl`.`Appointed_Date`, `appointments_tbl`.`Appointment_Reason` FROM `patients_tbl` LEFT JOIN `appointments_tbl` ON `appointments_tbl`.`PatientId` = `patients_tbl`.`Patient_TRN_Number` WHERE `patients_tbl`.`Patient_TRN_Number` = '" + ShowUsername.TRN + "'; ";
            Connection connection = new Connection();
            try
            {
                connection.Open();
                MySqlDataReader row;
                row = connection.ExecuteReader(query);

                if (row.HasRows)
                {
                    while (row.Read())
                    {
                        ShowAppointments.appointmentID.Add(row["AppointmentID"].ToString());
                        ShowAppointments.appointmentDate.Add(row["Appointed_Date"].ToString());
                        ShowAppointments.appointmentReason.Add(row["Appointment_Reason"].ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Nothing could be retreived");
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void populateAppointmentsGrid()
        {
            dgvAppointments.Rows.Clear();
            int count = 0;
            for (int i = 0; i < ShowAppointments.appointmentID.Count; i++) {
                DataGridViewRow newRow = new DataGridViewRow();

                newRow.CreateCells(dgvAppointments);
                count+=1;
                newRow.Cells[0].Value = count;
                newRow.Cells[1].Value = ShowAppointments.appointmentID[i];
                newRow.Cells[2].Value = ShowAppointments.appointmentDate[i];
                newRow.Cells[3].Value = ShowAppointments.appointmentReason[i];
                dgvAppointments.Rows.Add(newRow);
            }


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void FrmPatientAppointments_Load(object sender, EventArgs e)
        {
            getAppointments();
            if (ShowAppointments.appointmentID.Count > 0)
            {
                populateAppointmentsGrid();
            }
            else
            {
                MessageBox.Show("No data found");
            }
        }

        private void kryptonDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void btnNewAppointment_Click(object sender, EventArgs e)
        {
            FrmAddAppoinment frmAdd = new FrmAddAppoinment();
            frmAdd.ShowDialog();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
