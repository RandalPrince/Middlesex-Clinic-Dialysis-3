﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clinic_System
{
    internal class ShowAppointments
    {
        public static int totalFinishedAppointments;
        public static int totalPatients;
        public static int totalAppointments;
        
        // Appointment Portion
        public static ArrayList appointmentID = new ArrayList();
        public static ArrayList appointmentDate = new ArrayList();
        public static ArrayList appointmentReason = new ArrayList();

        // Patient Portion
        public static ArrayList patientFirstName = new ArrayList();
        public static ArrayList patientlasttName = new ArrayList();
        public static ArrayList patientAge = new ArrayList();
        public static ArrayList patientGender = new ArrayList();
        public static ArrayList patientID = new ArrayList();

    }
}
