﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clinic_System
{
    internal class ShowUsername
    {
        public static string displayName;

        // Show patients other details
        public static int patientID;
        public static int TRN;
        public static string patientFirstName;
        public static string patientLastName;
        public static string email;
        public static string age;
        public static string patientGender;
        public static string street;
        public static string parish;

    }
}
