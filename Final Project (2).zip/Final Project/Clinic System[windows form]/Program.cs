using MySql.Data.MySqlClient;

namespace Clinic_System
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // MYSQL Connection test
            //string server = "localhost";
            //string database = "clinicDB";
            //string username = "root_admin";
            //string password = "Test@000";
            //string connectionString = "SERVER="+ server+";"+"DATABASE="+database+";"+"UID="+username+";"+"PASSWORD="+password+";";
            string connectionString = "datasource=127.0.0.1;port=3306;username=root_admin;password=Test@000=;database=clinicDB;";
            MySqlConnection conn = new MySqlConnection(connectionString);

            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new FrmClinicManagement());
        }
    }
}