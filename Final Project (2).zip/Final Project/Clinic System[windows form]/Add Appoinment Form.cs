﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic_System
{
    public partial class FrmAddAppoinment : Form
    {
        public FrmAddAppoinment()
        {
            InitializeComponent();
        }

        private void trbCondition_Validating(object sender, CancelEventArgs e)
        {

        }

        private void btnAddAppointment_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled)){
                try
                {
                    // DateOnly aptdate = new DateOnly();
                    string aptdate = dtpAppointmentDate.Value.ToString("yyyy-M-dd");
                    int p_ID = ShowUsername.TRN;
                    Connection connection = new Connection();
                    connection.Open();
                    string query= "INSERT INTO `appointments_tbl`(`Appointment_Reason`, `Appointed_Date`, `Appointment_Status_ID`, `PatientId`) VALUES ('"+trbCondition.Text+"', '"+aptdate+ "','1','" + ShowUsername.TRN + "')";

                    // Create appoinment
                    try {
                        connection.ExecuteNonQuery(query);
                        MessageBox.Show("Your appointment has been successfully added");
                        connection.Close();
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show("Connection Error", "Information");
                    }
                    

                }
                catch(Exception ex)
                {
                    MessageBox.Show("Connection Error", "Information");
                }
            }
        }
    }
}
