﻿namespace Clinic_System
{
    partial class Pateint_Appointments_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblPatientAppointments = new System.Windows.Forms.Label();
            this.dgvAllPatientAppointments = new System.Windows.Forms.DataGridView();
            this.pnlAppointmentOverview = new System.Windows.Forms.Panel();
            this.lblFinishedAppointments = new System.Windows.Forms.Label();
            this.lblTotalAppoinments = new System.Windows.Forms.Label();
            this.lblTotalPatients = new System.Windows.Forms.Label();
            this.lblFinishedAppoinments = new System.Windows.Forms.Label();
            this.lblAppoinments = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new Krypton.Toolkit.KryptonDataGridViewButtonColumn();
            this.dgvbtnDiagnose = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllPatientAppointments)).BeginInit();
            this.pnlAppointmentOverview.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPatientAppointments
            // 
            this.lblPatientAppointments.AutoSize = true;
            this.lblPatientAppointments.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPatientAppointments.Location = new System.Drawing.Point(314, 20);
            this.lblPatientAppointments.Name = "lblPatientAppointments";
            this.lblPatientAppointments.Size = new System.Drawing.Size(207, 25);
            this.lblPatientAppointments.TabIndex = 0;
            this.lblPatientAppointments.Text = "Patient Appointments";
            // 
            // dgvAllPatientAppointments
            // 
            this.dgvAllPatientAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAllPatientAppointments.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.dgvbtnDiagnose});
            this.dgvAllPatientAppointments.Location = new System.Drawing.Point(36, 171);
            this.dgvAllPatientAppointments.Name = "dgvAllPatientAppointments";
            this.dgvAllPatientAppointments.ReadOnly = true;
            this.dgvAllPatientAppointments.RowTemplate.Height = 25;
            this.dgvAllPatientAppointments.Size = new System.Drawing.Size(733, 267);
            this.dgvAllPatientAppointments.TabIndex = 1;
            this.dgvAllPatientAppointments.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAllPatientAppointments_CellContentClick);
            // 
            // pnlAppointmentOverview
            // 
            this.pnlAppointmentOverview.Controls.Add(this.lblFinishedAppointments);
            this.pnlAppointmentOverview.Controls.Add(this.lblTotalAppoinments);
            this.pnlAppointmentOverview.Controls.Add(this.lblTotalPatients);
            this.pnlAppointmentOverview.Controls.Add(this.lblFinishedAppoinments);
            this.pnlAppointmentOverview.Controls.Add(this.lblAppoinments);
            this.pnlAppointmentOverview.Controls.Add(this.label2);
            this.pnlAppointmentOverview.Location = new System.Drawing.Point(108, 52);
            this.pnlAppointmentOverview.Name = "pnlAppointmentOverview";
            this.pnlAppointmentOverview.Size = new System.Drawing.Size(587, 97);
            this.pnlAppointmentOverview.TabIndex = 4;
            this.pnlAppointmentOverview.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlAppointmentOverview_Paint);
            // 
            // lblFinishedAppointments
            // 
            this.lblFinishedAppointments.AutoSize = true;
            this.lblFinishedAppointments.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblFinishedAppointments.Location = new System.Drawing.Point(448, 53);
            this.lblFinishedAppointments.Name = "lblFinishedAppointments";
            this.lblFinishedAppointments.Size = new System.Drawing.Size(28, 21);
            this.lblFinishedAppointments.TabIndex = 3;
            this.lblFinishedAppointments.Text = "32";
            // 
            // lblTotalAppoinments
            // 
            this.lblTotalAppoinments.AutoSize = true;
            this.lblTotalAppoinments.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblTotalAppoinments.Location = new System.Drawing.Point(239, 53);
            this.lblTotalAppoinments.Name = "lblTotalAppoinments";
            this.lblTotalAppoinments.Size = new System.Drawing.Size(26, 21);
            this.lblTotalAppoinments.TabIndex = 3;
            this.lblTotalAppoinments.Text = "32";
            this.lblTotalAppoinments.Click += new System.EventHandler(this.lblTotalAppoinments_Click);
            // 
            // lblTotalPatients
            // 
            this.lblTotalPatients.AutoSize = true;
            this.lblTotalPatients.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lblTotalPatients.Location = new System.Drawing.Point(70, 53);
            this.lblTotalPatients.Name = "lblTotalPatients";
            this.lblTotalPatients.Size = new System.Drawing.Size(26, 21);
            this.lblTotalPatients.TabIndex = 3;
            this.lblTotalPatients.Text = "32";
            this.lblTotalPatients.Click += new System.EventHandler(this.lblTotalPatients_Click);
            // 
            // lblFinishedAppoinments
            // 
            this.lblFinishedAppoinments.AutoSize = true;
            this.lblFinishedAppoinments.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblFinishedAppoinments.Location = new System.Drawing.Point(376, 25);
            this.lblFinishedAppoinments.Name = "lblFinishedAppoinments";
            this.lblFinishedAppoinments.Size = new System.Drawing.Size(206, 21);
            this.lblFinishedAppoinments.TabIndex = 2;
            this.lblFinishedAppoinments.Text = "Total Finished Appointments";
            // 
            // lblAppoinments
            // 
            this.lblAppoinments.AutoSize = true;
            this.lblAppoinments.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAppoinments.Location = new System.Drawing.Point(205, 25);
            this.lblAppoinments.Name = "lblAppoinments";
            this.lblAppoinments.Size = new System.Drawing.Size(144, 21);
            this.lblAppoinments.TabIndex = 2;
            this.lblAppoinments.Text = "Total Appointments";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(36, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 21);
            this.label2.TabIndex = 2;
            this.label2.Text = "Total Patients";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "no.";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "patient ID";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "First Name";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Last Name";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Age";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Gender";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Appointment Reason";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            this.Column8.DefaultCellStyle = dataGridViewCellStyle1;
            this.Column8.HeaderText = "View";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Text = "View";
            // 
            // dgvbtnDiagnose
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.dgvbtnDiagnose.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvbtnDiagnose.HeaderText = "Diagnose";
            this.dgvbtnDiagnose.Name = "dgvbtnDiagnose";
            this.dgvbtnDiagnose.ReadOnly = true;
            this.dgvbtnDiagnose.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvbtnDiagnose.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgvbtnDiagnose.Text = "Diagnose";
            // 
            // Pateint_Appointments_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlAppointmentOverview);
            this.Controls.Add(this.dgvAllPatientAppointments);
            this.Controls.Add(this.lblPatientAppointments);
            this.Name = "Pateint_Appointments_Form";
            this.Text = "Pateint_Appointments_Form";
            this.Load += new System.EventHandler(this.Pateint_Appointments_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllPatientAppointments)).EndInit();
            this.pnlAppointmentOverview.ResumeLayout(false);
            this.pnlAppointmentOverview.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblPatientAppointments;
        private DataGridView dgvAllPatientAppointments;
        private Panel pnlAppointmentOverview;
        private Label lblFinishedAppointments;
        private Label lblTotalAppoinments;
        private Label lblTotalPatients;
        private Label lblFinishedAppoinments;
        private Label lblAppoinments;
        private Label label2;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column7;
        private Krypton.Toolkit.KryptonDataGridViewButtonColumn Column8;
        private DataGridViewButtonColumn dgvbtnDiagnose;
    }
}