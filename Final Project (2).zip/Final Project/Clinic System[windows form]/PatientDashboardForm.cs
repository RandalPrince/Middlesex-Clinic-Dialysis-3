﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic_System
{
    public partial class FrmPatientDashboard : Form
    {
        public FrmPatientDashboard()
        {
            InitializeComponent();
        }
        

        private void btnLogout_Click(object sender, EventArgs e)
        {

        }

        private void btnLogout_Click_1(object sender, EventArgs e)
        {
            this.Visible = false;
            FrmLogin loginFrm = new FrmLogin();
            loginFrm.Show();
        }

        private void btnOpenAddAppointment_Click(object sender, EventArgs e)
        {
            FrmAddAppoinment frm_add_appointment = new FrmAddAppoinment();
            frm_add_appointment.Show();
        }

        // View Appointments
        private void button1_Click(object sender, EventArgs e)
        {
            FrmPatientAppointments frm_patient_appointments = new FrmPatientAppointments();
            frm_patient_appointments.Show();
        }

        private void lblPatientUsername_Click(object sender, EventArgs e)
        {

        }

        private void lblPatientUsername_TextChanged(object sender, EventArgs e)
        {
            lblPatientUsername.Text = ShowUsername.displayName;
        }

        private void pnlMiddle_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
                    }

        private void pnlLeft_Paint(object sender, PaintEventArgs e)
        {

        }

        private void kryptonButton2_Click(object sender, EventArgs e)
        {

        }

        private void kryptonButton1_Click(object sender, EventArgs e)
        {
                    }

        private void FrmPatientDashboard_Load(object sender, EventArgs e)
        {
            lblPatientUsername.Text = ShowUsername.displayName;
            try
            {
                Connection connection = new Connection();
                connection.Open();
                string query = "SELECT `user_login_tbl`.`User_ID`, `patients_tbl`.`Patient_TRN_Number`, `patients_tbl`.`First_Name`, `patients_tbl`.`Last_Name`, `patients_tbl`.`Gender`, `patients_tbl`.`Age`, `patients_tbl`.`Street`, `patients_tbl`.`Parish`, `user_login_tbl`.`Email` FROM `user_login_tbl` LEFT JOIN `patients_tbl` ON `patients_tbl`.`UserID` = `user_login_tbl`.`User_ID` WHERE `patients_tbl`.`UserID` = '" + ShowUsername.patientID + "'; ";
                DataTable userDataTable = new DataTable();
                MySqlDataReader row;
                row = connection.ExecuteReader(query);

                // Fetch Patient details ad populate labels
                userDataTable.Load(row);
                DataRow userRow = userDataTable.Rows[0];
                ShowUsername.patientFirstName = userRow["First_Name"].ToString();
                ShowUsername.patientLastName = userRow["Last_Name"].ToString();
                ShowUsername.street = userRow["Street"].ToString();
                ShowUsername.parish = userRow["Parish"].ToString();
                ShowUsername.email = userRow["Email"].ToString();
                ShowUsername.TRN = Convert.ToInt32(userRow["Patient_TRN_Number"]);
                ShowUsername.age = userRow["Age"].ToString();
                ShowUsername.patientGender = userRow["Gender"].ToString();
                ShowUsername.patientFirstName = userRow["First_Name"].ToString();
                ShowUsername.patientLastName = userRow["Last_Name"].ToString();

                // Populate Labels
                lblEmail.Text = ShowUsername.email;
                lblTRN.Text = ShowUsername.TRN.ToString();
                lblParish.Text = ShowUsername.parish;
                lblStreet.Text = ShowUsername.street;
                lblGender.Text = ShowUsername.patientGender;
                lblPatientFirstName.Text = ShowUsername.patientFirstName;
                lblPatientLastName.Text = ShowUsername.patientLastName;
                lblPatAge.Text = ShowUsername.age;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Connection Error", "Information");
            }
        }

        private void lblStreetheader_Click(object sender, EventArgs e)
        {

        }

        private void lblStreet_Click(object sender, EventArgs e)
        {

        }

        private void lblGender_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void lblParish_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblTRN_Click(object sender, EventArgs e)
        {

        }

        private void lblPatAge_Click(object sender, EventArgs e)
        {

        }

        private void kryptonPanel2_Paint(object sender, PaintEventArgs e)
        {
                    }

        private void pnlUserSection_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
