﻿namespace Clinic_System
{
    partial class FrmDoctorDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDoctorDashboard));
            this.lblDoctorWelcome = new System.Windows.Forms.Label();
            this.pnlLeft = new System.Windows.Forms.Panel();
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnPatientAppointments = new System.Windows.Forms.Button();
            this.panelUser = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblDrLName = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.pnlMiddle = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.lblDocLastName = new System.Windows.Forms.Label();
            this.lblDocFirstName = new System.Windows.Forms.Label();
            this.lblDocAge = new System.Windows.Forms.Label();
            this.lblDocTRN = new System.Windows.Forms.Label();
            this.lblDocParish = new System.Windows.Forms.Label();
            this.lblDocSpealization = new System.Windows.Forms.Label();
            this.lblDocGender = new System.Windows.Forms.Label();
            this.lblDocStreet = new System.Windows.Forms.Label();
            this.lblPatientAge = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.kryptonPanel1 = new Krypton.Toolkit.KryptonPanel();
            this.pnlLeft.SuspendLayout();
            this.panelUser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlMiddle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblDoctorWelcome
            // 
            this.lblDoctorWelcome.AutoSize = true;
            this.lblDoctorWelcome.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDoctorWelcome.Location = new System.Drawing.Point(12, 9);
            this.lblDoctorWelcome.Name = "lblDoctorWelcome";
            this.lblDoctorWelcome.Size = new System.Drawing.Size(123, 25);
            this.lblDoctorWelcome.TabIndex = 0;
            this.lblDoctorWelcome.Text = "Welcome Dr.";
            // 
            // pnlLeft
            // 
            this.pnlLeft.Controls.Add(this.btnLogin);
            this.pnlLeft.Controls.Add(this.btnPatientAppointments);
            this.pnlLeft.Controls.Add(this.panelUser);
            this.pnlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLeft.Location = new System.Drawing.Point(0, 0);
            this.pnlLeft.Name = "pnlLeft";
            this.pnlLeft.Size = new System.Drawing.Size(186, 360);
            this.pnlLeft.TabIndex = 1;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.IndianRed;
            this.btnLogin.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnLogin.Location = new System.Drawing.Point(0, 302);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(177, 36);
            this.btnLogin.TabIndex = 0;
            this.btnLogin.Text = "Logout";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // btnPatientAppointments
            // 
            this.btnPatientAppointments.BackColor = System.Drawing.Color.BurlyWood;
            this.btnPatientAppointments.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnPatientAppointments.Location = new System.Drawing.Point(0, 216);
            this.btnPatientAppointments.Name = "btnPatientAppointments";
            this.btnPatientAppointments.Size = new System.Drawing.Size(183, 46);
            this.btnPatientAppointments.TabIndex = 1;
            this.btnPatientAppointments.Text = "Appointments";
            this.btnPatientAppointments.UseVisualStyleBackColor = false;
            this.btnPatientAppointments.Click += new System.EventHandler(this.btnPatientAppointments_Click);
            // 
            // panelUser
            // 
            this.panelUser.Controls.Add(this.label2);
            this.panelUser.Controls.Add(this.pictureBox1);
            this.panelUser.Controls.Add(this.lblDrLName);
            this.panelUser.Controls.Add(this.lblWelcome);
            this.panelUser.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelUser.Location = new System.Drawing.Point(0, 0);
            this.panelUser.Name = "panelUser";
            this.panelUser.Size = new System.Drawing.Size(186, 188);
            this.panelUser.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(42, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "Dr.";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(26, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(143, 102);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lblDrLName
            // 
            this.lblDrLName.AutoSize = true;
            this.lblDrLName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDrLName.Location = new System.Drawing.Point(67, 160);
            this.lblDrLName.Name = "lblDrLName";
            this.lblDrLName.Size = new System.Drawing.Size(79, 21);
            this.lblDrLName.TabIndex = 1;
            this.lblDrLName.Text = "username";
            this.lblDrLName.Click += new System.EventHandler(this.lblDrUsername_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblWelcome.Location = new System.Drawing.Point(26, 123);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(143, 37);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome,";
            // 
            // pnlMiddle
            // 
            this.pnlMiddle.BackColor = System.Drawing.Color.DarkGray;
            this.pnlMiddle.Controls.Add(this.label7);
            this.pnlMiddle.Controls.Add(this.lblDocLastName);
            this.pnlMiddle.Controls.Add(this.lblDocFirstName);
            this.pnlMiddle.Controls.Add(this.lblDocAge);
            this.pnlMiddle.Controls.Add(this.lblDocTRN);
            this.pnlMiddle.Controls.Add(this.lblDocParish);
            this.pnlMiddle.Controls.Add(this.lblDocSpealization);
            this.pnlMiddle.Controls.Add(this.lblDocGender);
            this.pnlMiddle.Controls.Add(this.lblDocStreet);
            this.pnlMiddle.Controls.Add(this.lblPatientAge);
            this.pnlMiddle.Controls.Add(this.label5);
            this.pnlMiddle.Controls.Add(this.label3);
            this.pnlMiddle.Controls.Add(this.label8);
            this.pnlMiddle.Controls.Add(this.label4);
            this.pnlMiddle.Controls.Add(this.label6);
            this.pnlMiddle.Controls.Add(this.label1);
            this.pnlMiddle.Controls.Add(this.kryptonPanel1);
            this.pnlMiddle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMiddle.Location = new System.Drawing.Point(186, 0);
            this.pnlMiddle.Name = "pnlMiddle";
            this.pnlMiddle.Size = new System.Drawing.Size(703, 360);
            this.pnlMiddle.TabIndex = 2;
            this.pnlMiddle.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlMiddle_Paint);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(253, 252);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 15);
            this.label7.TabIndex = 17;
            this.label7.Text = "Street";
            // 
            // lblDocLastName
            // 
            this.lblDocLastName.AutoSize = true;
            this.lblDocLastName.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDocLastName.Location = new System.Drawing.Point(104, 171);
            this.lblDocLastName.Name = "lblDocLastName";
            this.lblDocLastName.Size = new System.Drawing.Size(103, 25);
            this.lblDocLastName.TabIndex = 10;
            this.lblDocLastName.Text = "Last Name";
            this.lblDocLastName.Click += new System.EventHandler(this.lblPatientLastName_Click);
            // 
            // lblDocFirstName
            // 
            this.lblDocFirstName.AutoSize = true;
            this.lblDocFirstName.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDocFirstName.Location = new System.Drawing.Point(45, 171);
            this.lblDocFirstName.Name = "lblDocFirstName";
            this.lblDocFirstName.Size = new System.Drawing.Size(106, 25);
            this.lblDocFirstName.TabIndex = 11;
            this.lblDocFirstName.Text = "First Name";
            // 
            // lblDocAge
            // 
            this.lblDocAge.AutoSize = true;
            this.lblDocAge.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDocAge.Location = new System.Drawing.Point(464, 171);
            this.lblDocAge.Name = "lblDocAge";
            this.lblDocAge.Size = new System.Drawing.Size(46, 25);
            this.lblDocAge.TabIndex = 12;
            this.lblDocAge.Text = "Age";
            this.lblDocAge.Click += new System.EventHandler(this.lblPatAge_Click);
            // 
            // lblDocTRN
            // 
            this.lblDocTRN.AutoSize = true;
            this.lblDocTRN.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDocTRN.Location = new System.Drawing.Point(253, 174);
            this.lblDocTRN.Name = "lblDocTRN";
            this.lblDocTRN.Size = new System.Drawing.Size(49, 25);
            this.lblDocTRN.TabIndex = 13;
            this.lblDocTRN.Text = "TRN";
            // 
            // lblDocParish
            // 
            this.lblDocParish.AutoSize = true;
            this.lblDocParish.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDocParish.Location = new System.Drawing.Point(464, 281);
            this.lblDocParish.Name = "lblDocParish";
            this.lblDocParish.Size = new System.Drawing.Size(63, 25);
            this.lblDocParish.TabIndex = 14;
            this.lblDocParish.Text = "Parish";
            // 
            // lblDocSpealization
            // 
            this.lblDocSpealization.AutoSize = true;
            this.lblDocSpealization.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDocSpealization.Location = new System.Drawing.Point(45, 281);
            this.lblDocSpealization.Name = "lblDocSpealization";
            this.lblDocSpealization.Size = new System.Drawing.Size(140, 25);
            this.lblDocSpealization.TabIndex = 15;
            this.lblDocSpealization.Text = "Speacialization";
            this.lblDocSpealization.Click += new System.EventHandler(this.lblGender_Click);
            // 
            // lblDocGender
            // 
            this.lblDocGender.AutoSize = true;
            this.lblDocGender.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDocGender.Location = new System.Drawing.Point(610, 174);
            this.lblDocGender.Name = "lblDocGender";
            this.lblDocGender.Size = new System.Drawing.Size(74, 25);
            this.lblDocGender.TabIndex = 15;
            this.lblDocGender.Text = "Gender";
            this.lblDocGender.Click += new System.EventHandler(this.lblGender_Click);
            // 
            // lblDocStreet
            // 
            this.lblDocStreet.AutoSize = true;
            this.lblDocStreet.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDocStreet.Location = new System.Drawing.Point(253, 278);
            this.lblDocStreet.Name = "lblDocStreet";
            this.lblDocStreet.Size = new System.Drawing.Size(62, 25);
            this.lblDocStreet.TabIndex = 16;
            this.lblDocStreet.Text = "Street";
            // 
            // lblPatientAge
            // 
            this.lblPatientAge.AutoSize = true;
            this.lblPatientAge.Location = new System.Drawing.Point(464, 145);
            this.lblPatientAge.Name = "lblPatientAge";
            this.lblPatientAge.Size = new System.Drawing.Size(28, 15);
            this.lblPatientAge.TabIndex = 5;
            this.lblPatientAge.Text = "Age";
            this.lblPatientAge.Click += new System.EventHandler(this.lblPatientAge_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(253, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "TRN";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(464, 252);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "Parish";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(45, 252);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 15);
            this.label8.TabIndex = 8;
            this.label8.Text = "Specialization";
            this.label8.Click += new System.EventHandler(this.label4_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(610, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "Gender";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(45, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 15);
            this.label6.TabIndex = 9;
            this.label6.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(206, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(286, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Dashboard Overview";
            // 
            // kryptonPanel1
            // 
            this.kryptonPanel1.AllowDrop = true;
            this.kryptonPanel1.AutoScroll = true;
            this.kryptonPanel1.Location = new System.Drawing.Point(3, 3);
            this.kryptonPanel1.Name = "kryptonPanel1";
            this.kryptonPanel1.Size = new System.Drawing.Size(697, 100);
            this.kryptonPanel1.TabIndex = 18;
            this.kryptonPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.kryptonPanel1_Paint);
            // 
            // FrmDoctorDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 360);
            this.Controls.Add(this.pnlMiddle);
            this.Controls.Add(this.pnlLeft);
            this.Controls.Add(this.lblDoctorWelcome);
            this.MaximizeBox = false;
            this.Name = "FrmDoctorDashboard";
            this.Text = "Doctor Dashboard";
            this.Load += new System.EventHandler(this.FrmDoctorDashboard_Load);
            this.pnlLeft.ResumeLayout(false);
            this.panelUser.ResumeLayout(false);
            this.panelUser.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlMiddle.ResumeLayout(false);
            this.pnlMiddle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblDoctorWelcome;
        private Panel pnlLeft;
        private Panel panelUser;
        private Label lblDrLName;
        private Label lblWelcome;
        private Panel pnlMiddle;
        private Label label1;
        private Button btnLogin;
        private Button btnPatientAppointments;
        private PictureBox pictureBox1;
        private Label label2;
        private Label lblDocLastName;
        private Label lblDocFirstName;
        private Label lblDocAge;
        private Label lblDocTRN;
        private Label lblDocParish;
        private Label lblDocGender;
        private Label lblDocStreet;
        private Label lblPatientAge;
        private Label label5;
        private Label label3;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label lblDocSpealization;
        private Label label8;
        private Krypton.Toolkit.KryptonPanel kryptonPanel1;
    }
}