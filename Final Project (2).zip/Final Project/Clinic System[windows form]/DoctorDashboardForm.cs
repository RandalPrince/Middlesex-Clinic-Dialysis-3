﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clinic_System
{
    public partial class FrmDoctorDashboard : Form
    {
        public FrmDoctorDashboard()
        {
            InitializeComponent();
        }

        private void lblTotalAppoinments_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btnPatientAppointments_Click(object sender, EventArgs e)
        {
            Pateint_Appointments_Form pateint_Appointments = new Pateint_Appointments_Form();
            pateint_Appointments.Show();
        }

        private void FrmDoctorDashboard_Load(object sender, EventArgs e)
        {
            try
            {
                Connection connection = new Connection();
                connection.Open();
                string query = "SELECT `user_login_tbl`.`User_ID`, `user_role_tbl`.`Role_ID`, `user_login_tbl`.`Username`, `user_login_tbl`.`Email`, `doctor_tbl`.`DoctorID`, `doctor_tbl`.`First_Name`, `doctor_tbl`.`Last_Name`, `doctor_tbl`.`Gender`, `doctor_tbl`.`Age`, `doctor_tbl`.`TRN_Number`, `doctor_tbl`.`Street`, `doctor_tbl`.`Parish`, `doctor_specialization_tbl`.`Specialization_Name` FROM `user_login_tbl` LEFT JOIN `user_role_tbl` ON `user_login_tbl`.`User_Role_ID` = `user_role_tbl`.`Role_ID` LEFT JOIN `doctor_tbl` ON `doctor_tbl`.`UserID` = `user_login_tbl`.`User_ID` LEFT JOIN `doctor_specialization_tbl` ON `doctor_tbl`.`SpecializationID` = `doctor_specialization_tbl`.`SpecializationID` WHERE `user_login_tbl`.`User_ID` = '" + ShowDoctor.DoctorUserID + "' AND `user_role_tbl`.`Role_ID` = '2'; ";
                DataTable userDataTable = new DataTable();
                MySqlDataReader row;
                row = connection.ExecuteReader(query);

                // Set the row columns to the variables in the class
                userDataTable.Load(row);
                DataRow userRow = userDataTable.Rows[0];

                ShowDoctor.Doctoremail = userRow["Email"].ToString();
                ShowDoctor.DoctorFirstName = userRow["First_Name"].ToString();
                ShowDoctor.DoctorLastName = userRow["Last_Name"].ToString();
                ShowDoctor.DoctorGender = userRow["Gender"].ToString();
                ShowDoctor.TRN = Convert.ToInt32(userRow["TRN_Number"]);
                ShowDoctor.age = userRow["Age"].ToString();
                ShowDoctor.parish = userRow["Parish"].ToString();
                ShowDoctor.street = userRow["Street"].ToString();
                ShowDoctor.specialization = userRow["Specialization_Name"].ToString();

                connection.Close();

                // Populate labels
                lblDrLName.Text = ShowDoctor.DoctorLastName;
                lblDocFirstName.Text = ShowDoctor.DoctorFirstName;
                lblDocLastName.Text = ShowDoctor.DoctorLastName;
                lblDocGender.Text = ShowDoctor.DoctorGender;
                lblDocAge.Text = ShowDoctor.age;
                lblDocTRN.Text = ShowDoctor.TRN.ToString();
                lblDocStreet.Text = ShowDoctor.street;
                lblDocParish.Text = ShowDoctor.parish;

            }
            catch(Exception ex)
            {

            }
        }

        private void lblAppoinments_Click(object sender, EventArgs e)
        {

        }

        private void lblFinishedAppoinments_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pnlAppointmentOverview_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblTotalPatients_Click(object sender, EventArgs e)
        {

        }

        private void btnPatients_Click(object sender, EventArgs e)
        {

        }

        private void pnlMiddle_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblDrUsername_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void lblPatientLastName_Click(object sender, EventArgs e)
        {

        }

        private void lblPatAge_Click(object sender, EventArgs e)
        {

        }

        private void lblGender_Click(object sender, EventArgs e)
        {

        }

        private void lblPatientAge_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void kryptonPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void kryptonPanel2_Paint(object sender, PaintEventArgs e)
        {
                   }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            FrmLogin loginFrm = new FrmLogin();
            loginFrm.Show();
        }
    }
}
