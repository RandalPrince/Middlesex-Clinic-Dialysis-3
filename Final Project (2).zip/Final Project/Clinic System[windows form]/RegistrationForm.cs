﻿using System.ComponentModel;
using System.Text.RegularExpressions;

namespace Clinic_System
{
    public partial class FrmRegistration : Form
    {
        public FrmRegistration()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            FrmClinicManagement splash_screen = new FrmClinicManagement();
            splash_screen.Show();
        }

        private void FrmRegistration_Load(object sender, EventArgs e)
        {

        }


        private void txtAge_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtAge.Text))
            {
                e.Cancel = true;
                txtUsername.Focus();
                registrationFormErrorProvider.SetError(txtAge, "Age name cannot be empty");
            }
        }

        private void txtFirstName_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtFirstName.Text))
            {
                e.Cancel = true;
                txtUsername.Focus();
                registrationFormErrorProvider.SetError(txtFirstName, "First name cannot be empty");
            }
            else
            {
                e.Cancel = false;
                registrationFormErrorProvider.SetError(txtFirstName, null);
            }
        }

        // Function to validate the lastname field
        private void txtLastName_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtLastName.Text))
            {
                e.Cancel = true;
                txtUsername.Focus();
                registrationFormErrorProvider.SetError(txtLastName, "Last name cannot be empty");
            }
            else
            {
                e.Cancel = false;
                registrationFormErrorProvider.SetError(txtLastName, null);
            }
        }

        // Function to validate the password textbox
        private void txtPassword_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtPassword.Text))
            {
                e.Cancel = true;
                txtUsername.Focus();
                registrationFormErrorProvider.SetError(txtPassword, "Password cannot be empty");
            }
            else
            {
                e.Cancel = false;
                registrationFormErrorProvider.SetError(txtPassword, null);
            }
        }

        // Function to validate the confirm password textbox
        private void txtConfirmPassword_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtConfirmPassword.Text))
            {
                e.Cancel = true;
                txtUsername.Focus();
                registrationFormErrorProvider.SetError(txtConfirmPassword, "Confirm Password cannot be empty");
            }
            else
            {
                e.Cancel = false;
                registrationFormErrorProvider.SetError(txtConfirmPassword, null);
            }
        }

        // // Function to validate the street name
        /*private void txtStreetName_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtStreetName.Text))
            {
                e.Cancel = true;
                txtUsername.Focus();
                registrationFormErrorProvider.SetError(txtStreetName, "Street name cannot be empty");
            }
            else
            {
                e.Cancel = false;
                registrationFormErrorProvider.SetError(txtStreetName, null);
            }
        }*/

        // Function to validate the parish
        /*private void txtParish_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtParish.Text))
            {
                e.Cancel = true;
                txtUsername.Focus();
                registrationFormErrorProvider.SetError(txtParish, "Parish cannot be empty");
            }
            else
            {
                e.Cancel = false;
                registrationFormErrorProvider.SetError(txtParish, null);
            }
        }*/

        // Function to validate the username
        private void txtUsername_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtUsername.Text))
            {
                e.Cancel = true;
                txtUsername.Focus();
                registrationFormErrorProvider.SetError(txtUsername, "Username name cannot be empty");
            }
            else
            {
                e.Cancel = false;
                registrationFormErrorProvider.SetError(txtUsername, null);
            }
        }

        // Helper function which hold the regex for a valid email structure
        private static Regex email_validation()
        {
            string pattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|"
                + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)"
                + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";

            return new Regex(pattern, RegexOptions.IgnoreCase);
        }

        static Regex validate_emailaddress = email_validation();

        // Function to validate emal
        private void txtEmail_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtEmail.Text))
            {
                e.Cancel = true;
                txtUsername.Focus();
                registrationFormErrorProvider.SetError(txtEmail, "Email cannot be empty");
            }
            else if(validate_emailaddress.IsMatch(txtEmail.Text) != true) {
                e.Cancel = true;
                txtUsername.Focus();
                registrationFormErrorProvider.SetError(txtEmail, "Email address is invalid");
            }
            else
            {
                e.Cancel = false;
                registrationFormErrorProvider.SetError(txtEmail, null);
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                string trn = txtTRNnum.Text;
                string firstName = txtFirstName.Text;
                string LastName = txtLastName.Text;
                string userName = txtUsername.Text;
                string email = txtEmail.Text;
                string password = txtPassword.Text;
                string Gender = "";

                if (rdbMale.Checked)
                {
                    Gender = "male";
                }
                else if (rdbFemale.Checked)
                {
                    Gender = "female";
                }

                string Age = txtAge.Text;
                string Street = txtStreetName.Text;
                string Parish = cmbParish.SelectedText.ToString();
                int userRole = 1;
                
                try
                {
                    Connection connection = new Connection();
                    connection.Open();

                    // Query one to insert data into user_login table
                    string query1 = "INSERT INTO `user_login_tbl`(`User_ID`, `Username`, `Email`, `UPassword`, `User_Role_ID`) VALUES(NULL, '" + userName + "', '" + email + "', '" + password + "', '" + userRole + "')";
                    connection.ExecuteNonQuery(query1);
 
                    string query2 = "INSERT INTO `patients_tbl`(`Patient_TRN_Number`, `First_Name`, `Last_Name`, `Gender`, `Age`, `Street`, `Parish`, `UserID`) VALUES ('" + trn + "','" + firstName + "', '" + LastName + "', '" + Gender + "', '" + Age + "', '" + Street + "', '" + Parish + "', LAST_INSERT_ID());";
                    connection.ExecuteNonQuery(query2);

                    MessageBox.Show("Registration SuccessFul!!", "You'll be redirected to login form", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Visible = false;
                    connection.Close();
                    FrmLogin login_form = new FrmLogin();
                    login_form.Show();

                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void txtAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verify that the pressed key isn't CTRL or any non-numeric digit
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

       // private void txtStreetName_TextChanged(object sender, EventArgs e)
        //{
//
       // }

        private void txtTRNnum_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(txtTRNnum.Text))
            {
                e.Cancel = true;
                txtTRNnum.Focus();
                registrationFormErrorProvider.SetError(txtTRNnum, "TRN cannot be empty");
            }

            else
            {
                e.Cancel = false;
                registrationFormErrorProvider.SetError(txtTRNnum, null);
            }
        }

        // Validating Parishes
        private void cmbParish_Validating(object sender, CancelEventArgs e)
        {
            if (cmbParish.SelectedIndex == -1)
            {
                // MessageBox.Show("You must select a Parish from the list", "Error");
                e.Cancel = true;
                cmbParish.Focus();
                registrationFormErrorProvider.SetError(txtEmail, "Email cannot be empty");
            }
        }


        private void txtAge_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
