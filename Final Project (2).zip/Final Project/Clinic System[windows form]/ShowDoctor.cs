﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clinic_System
{
    internal class ShowDoctor
    {
        // Show patients other details
        public static int DoctorUserID;
        public static string username;
        public static int TRN;
        public static string DoctorFirstName;
        public static string DoctorLastName;
        public static string Doctoremail;
        public static string age;
        public static string DoctorGender;
        public static string street;
        public static string parish;
        public static string specialization;
    }
}
