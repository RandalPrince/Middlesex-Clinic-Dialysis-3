﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Clinic_Application.Migrations
{
    public partial class Create : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "appointments_status_tbl",
                columns: table => new
                {
                    Status_ID = table.Column<int>(type: "int", maxLength: 11, nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Appointment_Status_Name = table.Column<string>(type: "Varchar(50)", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_appointments_status_tbl", x => x.Status_ID);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "doctor_specialization_tbl",
                columns: table => new
                {
                    SpecializationID = table.Column<int>(type: "int", maxLength: 11, nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Specialization_Name = table.Column<string>(type: "Varchar(150)", maxLength: 150, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_doctor_specialization_tbl", x => x.SpecializationID);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "doctor_tbl",
                columns: table => new
                {
                    DoctorID = table.Column<int>(type: "int", maxLength: 11, nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    First_Name = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Last_Name = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Gender = table.Column<string>(type: "varchar(10)", maxLength: 10, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Age = table.Column<int>(type: "int", maxLength: 11, nullable: false),
                    TRN_Number = table.Column<int>(type: "int", maxLength: 11, nullable: false),
                    Street = table.Column<string>(type: "varchar(255)", maxLength: 255, nullable: true)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Parish = table.Column<string>(type: "varchar(255)", maxLength: 255, nullable: true)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    SpecializationID = table.Column<int>(type: "int", maxLength: 11, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_doctor_tbl", x => x.DoctorID);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "patients_tbl",
                columns: table => new
                {
                    Patient_TRN_Number = table.Column<int>(type: "int", maxLength: 11, nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    First_Name = table.Column<string>(type: "varchar(30)", maxLength: 30, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Last_Name = table.Column<string>(type: "varchar(30)", maxLength: 30, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Gender = table.Column<string>(type: "varchar(10)", maxLength: 10, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Age = table.Column<int>(type: "int", maxLength: 11, nullable: false),
                    Street = table.Column<string>(type: "varchar(255)", maxLength: 255, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Parish = table.Column<string>(type: "varchar(15)", maxLength: 15, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_patients_tbl", x => x.Patient_TRN_Number);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "user_role_tbl",
                columns: table => new
                {
                    User_ID = table.Column<int>(type: "int", maxLength: 11, nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Username = table.Column<string>(type: "varchar(25)", maxLength: 25, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_user_role_tbl", x => x.User_ID);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "appointments_tbl",
                columns: table => new
                {
                    AppointmentID = table.Column<int>(type: "int", maxLength: 11, nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Appointment_Reason = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Appointed_Date = table.Column<DateTime>(type: "datetime(6)", nullable: false),
                    Appointment_Status_ID = table.Column<int>(type: "int", maxLength: 11, nullable: true),
                    PatientId = table.Column<int>(type: "int", maxLength: 11, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_appointments_tbl", x => x.AppointmentID);
                    table.ForeignKey(
                        name: "FK_appointments_tbl_appointments_status_tbl_Appointment_Status_~",
                        column: x => x.Appointment_Status_ID,
                        principalTable: "appointments_status_tbl",
                        principalColumn: "Status_ID");
                    table.ForeignKey(
                        name: "FK_appointments_tbl_patients_tbl_PatientId",
                        column: x => x.PatientId,
                        principalTable: "patients_tbl",
                        principalColumn: "Patient_TRN_Number");
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "user_login_tbl",
                columns: table => new
                {
                    User_ID = table.Column<int>(type: "int", maxLength: 11, nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Username = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    UPassword = table.Column<string>(type: "varchar(25)", maxLength: 25, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Patient_TRN_Number = table.Column<int>(type: "int", maxLength: 11, nullable: true),
                    DoctorID = table.Column<int>(type: "int", maxLength: 11, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_user_login_tbl", x => x.User_ID);
                    table.ForeignKey(
                        name: "FK_user_login_tbl_doctor_tbl_DoctorID",
                        column: x => x.DoctorID,
                        principalTable: "doctor_tbl",
                        principalColumn: "DoctorID");
                    table.ForeignKey(
                        name: "FK_user_login_tbl_patients_tbl_Patient_TRN_Number",
                        column: x => x.Patient_TRN_Number,
                        principalTable: "patients_tbl",
                        principalColumn: "Patient_TRN_Number");
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.InsertData(
                table: "doctor_tbl",
                columns: new[] { "DoctorID", "Age", "First_Name", "Gender", "Last_Name", "Parish", "SpecializationID", "Street", "TRN_Number" },
                values: new object[,]
                {
                    { 1, 0, "Jon", "Male", "Doh", null, null, null, 1234141 },
                    { 2, 0, "Mic", "Female", "dog", null, null, null, 1234141 }
                });

            migrationBuilder.InsertData(
                table: "patients_tbl",
                columns: new[] { "Patient_TRN_Number", "Age", "First_Name", "Gender", "Last_Name", "Parish", "Street" },
                values: new object[,]
                {
                    { 1, 30, "Jonathan", "Male", "Williams", "St.Andrew", "StonyHill" },
                    { 2, 30, "Michael", "Male", "Smith", "St.Thomas", "10 miles" }
                });

            migrationBuilder.InsertData(
                table: "user_login_tbl",
                columns: new[] { "User_ID", "DoctorID", "Patient_TRN_Number", "UPassword", "Username" },
                values: new object[,]
                {
                    { 1, 1, null, "1234", "User" },
                    { 2, 2, null, "123456", "User2" },
                    { 3, null, 1, "1234", "User3" },
                    { 4, null, 2, "1234", "User4" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_appointments_tbl_Appointment_Status_ID",
                table: "appointments_tbl",
                column: "Appointment_Status_ID");

            migrationBuilder.CreateIndex(
                name: "IX_appointments_tbl_PatientId",
                table: "appointments_tbl",
                column: "PatientId");

            migrationBuilder.CreateIndex(
                name: "IX_user_login_tbl_DoctorID",
                table: "user_login_tbl",
                column: "DoctorID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_user_login_tbl_Patient_TRN_Number",
                table: "user_login_tbl",
                column: "Patient_TRN_Number",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_user_login_tbl_Username",
                table: "user_login_tbl",
                column: "Username",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "appointments_tbl");

            migrationBuilder.DropTable(
                name: "doctor_specialization_tbl");

            migrationBuilder.DropTable(
                name: "user_login_tbl");

            migrationBuilder.DropTable(
                name: "user_role_tbl");

            migrationBuilder.DropTable(
                name: "appointments_status_tbl");

            migrationBuilder.DropTable(
                name: "doctor_tbl");

            migrationBuilder.DropTable(
                name: "patients_tbl");
        }
    }
}
