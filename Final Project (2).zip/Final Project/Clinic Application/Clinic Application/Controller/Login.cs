﻿using Clinic_Application.Data;
using Clinic_Application.Model;
using Microsoft.EntityFrameworkCore;

namespace Clinic_Application.Controller
{
    public class Login : ILogin
    {
        private readonly ClinicContext Db= new ClinicContext();
        public async Task<user_login_tbl?> LoginDetails(user_login_tbl LoginDetails)
        {
            var Query = Db.user_login_tbl;
            var result=Query.FirstOrDefaultAsync(x=>x.Username==LoginDetails.Username&&x.UPassword==LoginDetails.UPassword);
            if (Query != null)
            {
                return await result;
            }
            else
            {
                return null;
            }
        }
    }
}
