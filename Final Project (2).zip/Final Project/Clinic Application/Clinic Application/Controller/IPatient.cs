﻿namespace Clinic_Application.Controller
{
	public interface IPatient
	{
		
	}
}
