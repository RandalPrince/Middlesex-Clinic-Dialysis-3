﻿using Clinic_Application.Data;
using Clinic_Application.Model;
using Microsoft.EntityFrameworkCore;

namespace Clinic_Application.Controller
{
    public class Doctors:IDoctors
    {
        private readonly ClinicContext Db= new ClinicContext();

        public List<doctor_tbl> Docs { get; set; } = new List<doctor_tbl>();

        public async Task AddDoctor(doctor_tbl Doc )
        {
            Db.doctor_tbl.Add( Doc );
            await Db.SaveChangesAsync();
            
        }
        
        public async Task GetDoctors()
        {
            Docs=await Db.doctor_tbl.ToListAsync();
            
        }

        public async Task<patients_tbl> GetPatient(int? Id)
        {
            
                var result = Db.patients_tbl.FirstOrDefaultAsync(x => x.Patient_TRN_Number == Id);
                return await result;
            
            
        }

        

        public async Task<List<patients_tbl>> GetPatients()
		{
            var result=await Db.patients_tbl.ToListAsync();
            return result;
		}

        public  string UpdatePatient(patients_tbl pat)
        {
            try
            {
                var result = Db.patients_tbl.Update(pat);
                Db.SaveChanges();
                return "Patient TRN:"+ pat.Patient_TRN_Number + " Updated successfully.";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
            
        }
    }
}
