﻿using Clinic_Application.Model;

namespace Clinic_Application.Controller
{
    public interface IDoctors
    {
        public List<doctor_tbl> Docs { get; set; }
        public Task AddDoctor(doctor_tbl Doc);

        public Task<List<patients_tbl>> GetPatients();

        public string UpdatePatient(patients_tbl pat);


        public Task<patients_tbl> GetPatient(int? Id);
    }
}
