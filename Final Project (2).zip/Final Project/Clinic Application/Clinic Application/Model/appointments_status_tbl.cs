﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Clinic_Application.Model
{
    public class appointments_status_tbl
    {
        [Key]
        [MaxLength(11)]
        public int Status_ID { get; set; }

        [Required(ErrorMessage ="This Field cannot be empty")]
        [Column(TypeName = "Varchar(50)")]
        public string Appointment_Status_Name { get; set; } 
    }
}
