﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Clinic_Application.Model
{
    public class doctor_tbl
    {
        [Key]
        [MaxLength(11)]
        public int DoctorID { get; set; }

        [Required(ErrorMessage = "First name field is required.")]
        [MaxLength(50)]
        [Column(TypeName = "varchar")]
        public string First_Name { get; set; }

        [Required(ErrorMessage = "Last name field is required.")]
        [MaxLength(50)]
        [Column(TypeName = "varchar")]
        public string Last_Name { get; set; }

        [Required(ErrorMessage = "Gender field is required.")]
        [MaxLength(10)]
        [Column(TypeName = "varchar")]
        public string? Gender { get; set; }

        [Column(TypeName = "int")]
        [MaxLength(11)]
        [Required(ErrorMessage = "Aged field is required")]
        public int Age { get; set; }

        [Required]
        [Column(TypeName = "int")]
        [MaxLength(11)]
        public int? TRN_Number { get; set; }

        
        [Column(TypeName = "varchar")]
        [MaxLength(255)]
        public string? Street { get; set; }

        
        [Column(TypeName = "varchar")]
        [MaxLength(255)]
        public string? Parish { get; set; }

        public user_login_tbl? user_login_tbl { get; set; }

        [Column(TypeName = "int")]
        [MaxLength(11)]
        public int? SpecializationID { get; set;}


    }
}
