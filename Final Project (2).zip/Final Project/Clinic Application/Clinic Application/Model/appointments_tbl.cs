﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Clinic_Application.Model
{
    public class appointments_tbl
    {
        [Key]
        [MaxLength(11)]
        public int AppointmentID { get; set; }

        [Required(ErrorMessage = "An appointment reason must be given")]
        [Column(TypeName = "varchar")]
        [MaxLength(500)]
        public string Appointment_Reason { get; set; }

        [Required(ErrorMessage = "Date must be entered")]
        public DateTime Appointed_Date { get; set; }

        [ForeignKey("appointments_status_tbl")]
        [MaxLength(11)]
        public int? Appointment_Status_ID { get; set; }
        [MaxLength(11)]

        [ForeignKey("patients_tbl")]
        public int? PatientId { get; set; }

        //Navigation

        public virtual appointments_status_tbl appointments_status_tbl { get; set;}
        public virtual patients_tbl patients_tbl { get; set; }
    }
}
